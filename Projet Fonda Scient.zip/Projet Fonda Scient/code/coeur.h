#ifndef COEUR_H_INCLUDED
#define COEUR_H_INCLUDED

// Definition des prototypes pour allumer les LED

void fonction();
void Chenille();
void ALL_open_LED();
void LED_1_sur_2();
void LED_1_sur_3_v2();
void battementdecoeur();
void LED1();
void LED2();
void LED3();
void LED4();
void LED5();
void LED6();
void LED7();
void LED8();
void LED9();
void LED10();

#endif // COEUR_H_INCLUDED
