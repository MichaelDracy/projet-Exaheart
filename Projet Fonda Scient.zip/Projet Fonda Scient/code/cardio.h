#ifndef CARDIO_H_INCLUDED
#define CARDIO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>


  int bpm(int tempsPrecedent, int tempsDetection);  // on donne le prototype de la fonction et ses parametre


#endif // CARDIO_H_INCLUDED
