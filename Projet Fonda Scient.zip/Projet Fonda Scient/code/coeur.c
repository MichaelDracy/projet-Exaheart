const int pinLed[10]={2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
#include <Arduino.h>
#include "coeur.h"
#include "param.h"


void fonction()
{

//On definit les choix
  
  if (choix == 1)
  Chenille();
  
  if(choix == 2)
  All_open_LED();
  
  if (choix == 3)
  LED_1_sur_2();
  
  if (choix == 4)
  LED_1_sur_3_v2();
  
  if (choix == 5)
  battementdecoeur();

  if (choix == 6)
  LED1();

  if (choix == 7)
  LED2();

 if (choix == 8)
  LED3();

  if (choix == 9)
  LED4();

  if (choix == 10)
  LED5();

  if (choix == 11)
  LED6();

  if (choix == 12)
  LED7();

  if (choix == 13)
  LED8();

  if (choix == 14)
  LED9();

  if (choix == 15)
  LED10();
  
  }
void Chenille() // declaration de la chenille
{
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  delay(500);
  digitalWrite(pinLed[1], HIGH);
  delay(500);
  digitalWrite(pinLed[2], HIGH);
  delay(500);
  digitalWrite(pinLed[3], HIGH);
  delay(500);
  digitalWrite(pinLed[4], HIGH);
  delay(500);
  digitalWrite(pinLed[5], HIGH);
  delay(500);
  digitalWrite(pinLed[6], HIGH);
  delay(500);
  digitalWrite(pinLed[7], HIGH);
  delay(500);
  digitalWrite(pinLed[8], HIGH);
  delay(500);
  digitalWrite(pinLed[9], HIGH);
  delay(500);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(500);
}

void All_open_LED() // declaration de la variable pour allumer toutes les LED
{
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[8], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(500);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(500);
}

void LED_1_sur_2() // declaration de la variable pour allumer 1 LED sur 2
{
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[8], HIGH);
  delay(200);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[8], LOW);
  
    //test allumage et repérage des lEDs
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(200);
  //on éteint tout
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[9], LOW);
  
}

void LED_1_sur_3_v2() // declaration de la variable pour allumer 1 LED sur 3
{
  //test allumage et repérage des lEDs

  digitalWrite(pinLed[2], HIGH);

  digitalWrite(pinLed[5], HIGH);

  digitalWrite(pinLed[8], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[2], LOW);

  digitalWrite(pinLed[5], LOW);

  digitalWrite(pinLed[8], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[3], HIGH);

  digitalWrite(pinLed[6], HIGH);

  digitalWrite(pinLed[9], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[3], LOW);

  digitalWrite(pinLed[6], LOW);

  digitalWrite(pinLed[9], LOW);

 
  //test allumage et repérage des lEDs

  digitalWrite(pinLed[4], HIGH);

  digitalWrite(pinLed[7], HIGH);

  digitalWrite(pinLed[0], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[4], LOW);

  digitalWrite(pinLed[7], LOW);

  digitalWrite(pinLed[0], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[5], HIGH);

  digitalWrite(pinLed[8], HIGH);

  digitalWrite(pinLed[1], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[5], LOW);

  digitalWrite(pinLed[8], LOW);

  digitalWrite(pinLed[1], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[6], HIGH);

  digitalWrite(pinLed[9], HIGH);

  digitalWrite(pinLed[2], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[6], LOW);

  digitalWrite(pinLed[9], LOW);

  digitalWrite(pinLed[2], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[7], HIGH);

  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[3], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[7], LOW);

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[3], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[8], HIGH);

  digitalWrite(pinLed[1], HIGH);

  digitalWrite(pinLed[4], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[8], LOW);

  digitalWrite(pinLed[1], LOW);

  digitalWrite(pinLed[4], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[9], HIGH);

  digitalWrite(pinLed[2], HIGH);

  digitalWrite(pinLed[5], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[9], LOW);

  digitalWrite(pinLed[2], LOW);

  digitalWrite(pinLed[5], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[3], HIGH);

  digitalWrite(pinLed[6], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[3], LOW);

  digitalWrite(pinLed[6], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[1], HIGH);

  digitalWrite(pinLed[4], HIGH);

  digitalWrite(pinLed[7], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[1], LOW);

  digitalWrite(pinLed[4], LOW);

  digitalWrite(pinLed[7], LOW);
}

void battementdecoeur() // declaration de la variable pour allumer les LED comme un battement de coeur
{
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[8], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(200);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(75);
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[8], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(400);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(400);
}

void LED1() {
  digitalWrite(pinLed[0], HIGH);
  delay(50);
  digitalWrite(pinLed[0], LOW);
  delay(50);
}

void LED2() {
  digitalWrite(pinLed[1], HIGH);
  delay(50);
  digitalWrite(pinLed[1], LOW);
  delay(50);
}

void LED3() {
  digitalWrite(pinLed[2], HIGH);
  delay(50);
  digitalWrite(pinLed[2], LOW);
  delay(50);
}

void LED4() {
  digitalWrite(pinLed[3], HIGH);
  delay(50);
  digitalWrite(pinLed[3], LOW);
  delay(50);
}
void LED5() {
  digitalWrite(pinLed[4], HIGH);
  delay(50);
  digitalWrite(pinLed[4], LOW);
  delay(50);
}

void LED6() {
  digitalWrite(pinLed[5], HIGH);
  delay(50);
  digitalWrite(pinLed[5], LOW);
  delay(50);
}

void LED7() {
  digitalWrite(pinLed[6], HIGH);
  delay(50);
  digitalWrite(pinLed[6], LOW);
  delay(50);
}

void LED8() {
  digitalWrite(pinLed[7], HIGH);
  delay(50);
  digitalWrite(pinLed[7], LOW);
  delay(50);
}

void LED9() {
  digitalWrite(pinLed[8], HIGH);
  delay(50);
  digitalWrite(pinLed[8], LOW);
  delay(50);
}

void LED10() {
  digitalWrite(pinLed[9], HIGH);
  delay(50);
  digitalWrite(pinLed[9], LOW);
  delay(50);
}
