#ifndef GENERATIONCODE_H_INCLUDED
#define GENERATIONCODE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Chenille();

void All_open_LED();

void LED_1_sur_2();

void LED_1_sur_3_v2();

void battementdecoeur();

void LED1();

void LED2();

void LED3();

void LED4();

void LED5();

void LED6();

void LED7();

void LED8();

void LED9();

void LED10();

#endif // GENERATIONCODE_H_INCLUDED
