#include <stdio.h>
#include <stdlib.h>

 void menu()
{

   int a=0;


    printf("quel programme voulez-vous choisir?\n")
    printf("1. Chenille\n")
    printf("2. Toutes les LEDs\n")
    printf("3. 1 LED sur 2\n")
    printf("4. 1 LED sur 3\n")
    printf("5. Battement de coeur\n")
    printf("6-15. Choix de la LED � allumer de 1 a 10\n");
    scanf("%d",  &a);

    switch (a)
    {

    case 1 :
    printf("le programme choisit est Chenille");
    Chenille();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 2 :
    printf("le programme chosit est Toutes les LEDs");
    All_open_LED();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 3 :
    printf("le programme choisit est 1 LED sur 2");
    LED_1_sur_2();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 4 :
    printf("le programme choisit est 1 LED sur 3");
    LED_1_sur_3_v2();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 5 :
    printf("le programme choisit est Battement de coeur ");
    battementdecoeur();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 6 :
    printf("le programme choisit est LED1 ");
    LED1();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 7 :
    printf("le programme choisit est LED2 ");
    LED2();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 8 :
    printf("le programme choisit est LED3 ");
     LED3();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 9 :
    printf("le programme choisit est LED4 ");
     LED4();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 10 :
    printf("le programme choisit est LED5 ");
     LED5();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 11 :
    printf("le programme choisit est LED6 ");
     LED6();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;


    case 12 :
    printf("le programme choisit est LED7 ");
     LED7();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 13 :
    printf("le programme choisit est LED8 ");
     LED8();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 14 :
    printf("le programme choisit est LED9 ");
     LED9();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;

    case 15 :
    printf("le programme choisit est LED10 ");
     LED10();
    system("start Users/pierr/Desktop/Projet Fonda Scient/code/code.ino");
    break;
    }



}
