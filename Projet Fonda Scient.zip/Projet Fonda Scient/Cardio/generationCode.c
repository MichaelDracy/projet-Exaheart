#include <stdio.h>
#include <stdlib.h>


/*1*/void Chenille()
{

    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f, "#define choix 1");


}
/*2*/void All_open_LED()
{

    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 2");



}
/*3*/void LED_1_sur_2()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 3");

}
/*4*/void LED_1_sur_3_v2()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"define choix 4");
}
/*5*/void battementdecoeur()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 5");

}
/*6*/void LED1()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 6");

}
/*7*/void LED2()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 7");

}
/*8*/void LED3()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 8");

}
/*9*/void LED4()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 9");

}
/*10*/void LED5()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 10");

}
/*11*/void LED6()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 11");

}
/*12*/void LED7()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 12");

}
/*13*/void LED8()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 13");

}
/*14*/void LED9()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 14");

}
/*15*/void LED10()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\Projet Fonda Scient\\code\\param.h", "w");
    fprintf(f,"#define choix 15");

}
