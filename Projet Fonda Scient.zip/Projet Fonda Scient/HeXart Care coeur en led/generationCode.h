#ifndef GENERATIONCODE_H_INCLUDED
#define GENERATIONCODE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Chenille();

void All_open_LED();

void LED_1_sur_2();

void LED_1_sur_3_v2();

void battementdecoeur();


#endif // GENERATIONCODE_H_INCLUDED
