#include <stdio.h>
#include <stdlib.h>


void Chenille()
{

    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\coeur.c\\param.h", "w");
    fprintf(f, "#define choix 1");


}
void All_open_LED()
{

    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\coeur.c\\param.h", "w");
    fprintf(f,"#define choix 2");



}
void LED_1_sur_2()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\coeur.c\\param.h", "w");
    fprintf(f,"#define choix 3");

}
void LED_1_sur_3_v2()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\coeur.c\\param.h", "w");
    fprintf(f,"define choix 4");
}
void battementdecoeur()
{
    FILE* f = NULL;

    f = fopen("C:\\Users\\pierr\\Desktop\\coeur.c\\param.h", "w");
    fprintf(f,"#define choix 5");

}
