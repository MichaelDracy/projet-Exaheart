#include <stdio.h>
#include <stdlib.h>

 void menu()
{

   int a=0;


    printf("quel programme voulez-vous choisir?\n 1. Chenille\n 2. All_open_LED\n 3. 1_led_sur_2\n 4. 1_led_sur_3_v2\n 5. battement_de_coeur\n");
    scanf("%d",  &a);

    switch (a)
    {

    case 1 :
    printf("le programme choisit est Chenille");
    Chenille();
    break;

    case 2 :
    printf("le programme chosit est ALL_open_LED");
    All_open_LED();
    break;

    case 3 :
    printf("le programme choisit est 1_led_sur_2");
    LED_1_sur_2();
    break;

    case 4 :
    printf("le programme choisit est 1_led_sur_3_v2");
    LED_1_sur_3_v2();
    break;

    case 5 :
    printf("le programme choisit est battement_de_coeur ");
    battementdecoeur();
    break;
    }
}
