#ifndef COEUR_H_INCLUDED
#define COEUR_H_INCLUDED

const int pinLed[10]={2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
int a = 0;
void chenille();
void AllOpenLED ();
void LED1sur2 ();
void LED1sur3 ();

#endif // COEUR_H_INCLUDED

