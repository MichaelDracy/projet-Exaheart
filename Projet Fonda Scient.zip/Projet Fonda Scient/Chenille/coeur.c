const int pinLed[10]={2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
void setup()
{
  //initialisation des modes
  pinMode(pinLed[0], OUTPUT);
  pinMode(pinLed[1], OUTPUT);
  pinMode(pinLed[2], OUTPUT);
  pinMode(pinLed[3], OUTPUT);
  pinMode(pinLed[4], OUTPUT);
  pinMode(pinLed[5], OUTPUT);
  pinMode(pinLed[6], OUTPUT);
  pinMode(pinLed[7], OUTPUT);
  pinMode(pinLed[8], OUTPUT);
  pinMode(pinLed[9], OUTPUT);
