#ifndef COEUR_H_INCLUDED
#define COEUR_H_INCLUDED
void chenille() {
  //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  delay(500);
  digitalWrite(pinLed[1], HIGH);
  delay(500);
  digitalWrite(pinLed[2], HIGH);
  delay(500);
  digitalWrite(pinLed[3], HIGH);
  delay(500);
  digitalWrite(pinLed[4], HIGH);
  delay(500);
  digitalWrite(pinLed[5], HIGH);
  delay(500);
  digitalWrite(pinLed[6], HIGH);
  delay(500);
  digitalWrite(pinLed[7], HIGH);
  delay(500);
  digitalWrite(pinLed[8], HIGH);
  delay(500);
  digitalWrite(pinLed[9], HIGH);
  delay(500);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(500);
}

void AllOpenLED () {
    //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[8], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(1000);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[8], LOW);
  digitalWrite(pinLed[9], LOW);
  delay(1000);
}

void LED1sur2 () {
    //test allumage et repérage des lEDs
    //test allumage et repérage des lEDs
  digitalWrite(pinLed[0], HIGH);
  digitalWrite(pinLed[2], HIGH);
  digitalWrite(pinLed[4], HIGH);
  digitalWrite(pinLed[6], HIGH);
  digitalWrite(pinLed[8], HIGH);
  delay(200);
  //on éteint tout
  digitalWrite(pinLed[0], LOW);
  digitalWrite(pinLed[2], LOW);
  digitalWrite(pinLed[4], LOW);
  digitalWrite(pinLed[6], LOW);
  digitalWrite(pinLed[8], LOW);
  
    //test allumage et repérage des lEDs
  digitalWrite(pinLed[1], HIGH);
  digitalWrite(pinLed[3], HIGH);
  digitalWrite(pinLed[5], HIGH);
  digitalWrite(pinLed[7], HIGH);
  digitalWrite(pinLed[9], HIGH);
  delay(200);
  //on éteint tout
  digitalWrite(pinLed[1], LOW);
  digitalWrite(pinLed[3], LOW);
  digitalWrite(pinLed[5], LOW);
  digitalWrite(pinLed[7], LOW);
  digitalWrite(pinLed[9], LOW);
}

void LED1sur3 () {
    //test allumage et repérage des lEDs

  digitalWrite(pinLed[2], HIGH);

  digitalWrite(pinLed[5], HIGH);

  digitalWrite(pinLed[8], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[2], LOW);

  digitalWrite(pinLed[5], LOW);

  digitalWrite(pinLed[8], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[3], HIGH);

  digitalWrite(pinLed[6], HIGH);

  digitalWrite(pinLed[9], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[3], LOW);

  digitalWrite(pinLed[6], LOW);

  digitalWrite(pinLed[9], LOW);

 
  //test allumage et repérage des lEDs

  digitalWrite(pinLed[4], HIGH);

  digitalWrite(pinLed[7], HIGH);

  digitalWrite(pinLed[0], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[4], LOW);

  digitalWrite(pinLed[7], LOW);

  digitalWrite(pinLed[0], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[5], HIGH);

  digitalWrite(pinLed[8], HIGH);

  digitalWrite(pinLed[1], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[5], LOW);

  digitalWrite(pinLed[8], LOW);

  digitalWrite(pinLed[1], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[6], HIGH);

  digitalWrite(pinLed[9], HIGH);

  digitalWrite(pinLed[2], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[6], LOW);

  digitalWrite(pinLed[9], LOW);

  digitalWrite(pinLed[2], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[7], HIGH);

  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[3], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[7], LOW);

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[3], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[8], HIGH);

  digitalWrite(pinLed[1], HIGH);

  digitalWrite(pinLed[4], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[8], LOW);

  digitalWrite(pinLed[1], LOW);

  digitalWrite(pinLed[4], LOW);


    //test allumage et repérage des lEDs

  digitalWrite(pinLed[9], HIGH);

  digitalWrite(pinLed[2], HIGH);

  digitalWrite(pinLed[5], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[9], LOW);

  digitalWrite(pinLed[2], LOW);

  digitalWrite(pinLed[5], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[3], HIGH);

  digitalWrite(pinLed[6], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[3], LOW);

  digitalWrite(pinLed[6], LOW);


  //test allumage et repérage des lEDs

  digitalWrite(pinLed[1], HIGH);

  digitalWrite(pinLed[4], HIGH);

  digitalWrite(pinLed[7], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[1], LOW);

  digitalWrite(pinLed[4], LOW);

  digitalWrite(pinLed[7], LOW);
}

void LED1sur4 () {
  //Nouvelle boucle
  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[5], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[5], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[1], HIGH);

  digitalWrite(pinLed[6], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[1], LOW);

  digitalWrite(pinLed[6], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[2], HIGH);

  digitalWrite(pinLed[7], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[2], LOW);

  digitalWrite(pinLed[7], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[3], HIGH);

  digitalWrite(pinLed[8], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[4], LOW);

  digitalWrite(pinLed[8], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[5], HIGH);

  digitalWrite(pinLed[9], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[5], LOW);

  digitalWrite(pinLed[9], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[6], HIGH);

  digitalWrite(pinLed[0], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[6], LOW);

  digitalWrite(pinLed[0], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[7], HIGH);

  digitalWrite(pinLed[1], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[7], LOW);

  digitalWrite(pinLed[1], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[8], HIGH);

  digitalWrite(pinLed[2], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[8], LOW);

  digitalWrite(pinLed[2], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[9], HIGH);

  digitalWrite(pinLed[3], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[9], LOW);

  digitalWrite(pinLed[3], LOW);

  //Nouvelle boucle
  digitalWrite(pinLed[0], HIGH);

  digitalWrite(pinLed[4], HIGH);

  delay(200);
  //on éteint tout

  digitalWrite(pinLed[0], LOW);

  digitalWrite(pinLed[4], LOW);
}
  


#endif // COEUR_H_INCLUDED

