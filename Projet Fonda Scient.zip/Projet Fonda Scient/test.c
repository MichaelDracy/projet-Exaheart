#include <stdio.h>
#include <stdlib.h>

int fclose(FILE* fichier);

void tri_insertion(int* t)
{
    int i, j;
    int en_cours;

    for (i = 1; i < 20; i++) {
        en_cours = t[i];
        for (j = i; j > 0 && t[j - 1] > en_cours; j--) {
            t[j] = t[j - 1];
        }
        t[j] = en_cours;
    }
}

int LongueurFichier( char *CheminFichier )
{
    FILE *Fichier = fopen(CheminFichier,"r");
    int Longueur=0;
    char c;

    if(Fichier != NULL)
      {
               while(fscanf(Fichier,"%c",&c) != EOF)
                    {
                        Longueur++;
                    }
      }

    fclose(Fichier);
    return Longueur;
}

int main() {



}
