#include<stdlib.h>
#include<stdio.h>

switch (choice)
{
    case 1:
      printf("Donn�es du fichier .csv dans son ordre");
      break;
    case 2:
      printf("Donn�es de vos tests");
      break;
    case 3:
      printf("Vos donn�es sur une plage temporelle pr�cise");
      break;
    case 4:
      printf("Donn�es de votre pouls sur un intervalle de temps choisit ");
      break;
    case 5:
      printf("Donn�es enregistr�es");
      break;
    case 6:
      printf("Votre pouls minimum et/ou maximum en fonction du temps");
      break;
    case 7:
      printf("Fermer l'application");
      break;
    }

    return 0;
