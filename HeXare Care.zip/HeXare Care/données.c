#include <stdlib.h>
#include <stdio.h>

FILE* fopen(const char* fichier, const char* r+);

int main()
{
    FILE* fichier = NULL;
}
    fichier = fopen("Battements", "r+")
if(FIle* fichier  != NULL)
{
printf("Vous pouvez lire et/ou r��crire le fichier")
}
else
{
    printf("Le fichier n'a pas pu �tre ouvert. Pas de donn�e � lire")
}
