#include <stdio.h>
#include <stdlib.h>
#include "donn�es.h"
#include "actions.h"
#include "menu.h"

int main()
{

    return 0;
}
